#include <iostream>
using namespace std;

// Nama Anggota
// Ngasiroh Nurjayatri 2257051032
// Evi Nur Rahma Wati 2217051010

int total(int jumlah){ 
	int y = jumlah;
	return y; 
}	

void judul (){
	cout << "======================================================"<<endl;
	cout << "\t SELAMAT DATANG DI TOKO SEPATU NUREVI \t"<<endl;
	cout << "\tGEDONG MENENG, RAJA BASA, BANDAR LAMPUNG \t " <<endl;
	cout << "======================================================"<<endl;
}
void closejudul (){
	cout << "======================================================"<<endl;
	cout << "\t\t THANK YOU FOR ORDER \t\t"<<endl;
	cout << "======================================================"<<endl;
}

int main (){
	int jumlah;
	string nama, merkspt, ya;
	int jumlahtransaksi;
	int harga [10], bayar, uangkurang;
	char kodespt;
	
	do {
	system("CLS");
	judul (); 
	cout <<endl;
	
	cout <<"DAFTAR MERK SEPATU"<<endl;
	cout <<"1. Converse\t Rp. 90000"<<endl;
	cout <<"2. Adidas \t Rp. 120000"<<endl;
	cout <<"3. Levis \t Rp. 70000"<<endl;
	cout <<"4. Bata \t Rp. 200000"<<endl;
	cout <<"5. Nike \t Rp. 150000"<<endl;
	cout <<"6. Vans \t Rp. 100000"<<endl;
	cout <<"7. Puma \t Rp. 75000"<<endl;
	
	cout <<endl;
	cout <<"Nama Customer\t\t :";getline (cin, nama);
	cout << "Halo " << nama;
	cout << " Selamat Datang di Toko Sepatu Nurevi!" <<endl;
	cout <<endl;
	cout <<"Jumlah Transaksi\t :" ; cin >> jumlahtransaksi;
	cout <<endl;
	

	for (int x=1; x<=jumlahtransaksi; x++){
		    cout << "Barang ke-" << x <<endl; 
			cout << "Kode Sepatu [1/2/3/4/5/6/7]\t 	: "; cin >> kodespt;
			
		if (kodespt == '1'){
			cout << "Barang yang anda pilih\t 		: Converse"<<endl;  
			harga[x]=90000;
			
		} else if (kodespt == '2'){
			cout << "Barang yang anda pilih\t		: Adidas"<<endl;
			harga[x]=120000;
			
		} else if (kodespt == '3'){
			cout << "Barang yang anda pilih\t 		: Levis"<<endl; 
			harga[x]=70000;
			
		} else if (kodespt == '4'){
			cout << "Barang yang anda pilih\t 		: Bata"<<endl; 
			harga[x]=200000;
			
		} else if (kodespt == '5'){
			cout << "Barang yang anda pilih\t 		: Nike"<<endl; 
			harga[x]=150000;
			
    	}else if (kodespt  == '6'){
    		cout << "Barang yang anda pilih\t 		: Vans"<<endl;
    		harga[x]=100000;
    		
		}else if (kodespt == '7'){
			cout << " Barang yang anda pilih\t		: Puma"<<endl;
			harga[x]=75000;
			
		} else {
			cout << "Kode Sepatu Yang Anda Masukkan tidak Tersedia" <<endl; 
		}
		jumlah += harga[x];
	}
	
	cout <<endl;
	cout << "Jumlah Bayar\t\t 	:" "Rp. " << jumlah <<endl;
	cout << "Total Bayar\t\t 	:" << "Rp. " <<total (jumlah) <<endl;
	cout << "Bayar\t\t\t 	:" << "Rp. "; cin >> bayar;
	
	if (bayar<total(jumlah)){
		cout <<"===Uang Anda Tidak Cukup==="<<endl;
		cout << "silakan transaksi kembali : Rp. "; 
		cin >> uangkurang;
		bayar += uangkurang;
	}
	
	cout << "Kembali\t\t 		:" << "Rp. " << bayar-total(jumlah) <<endl;
	cout <<endl;
	cout << "Apakah anda ingin membeli lagi?  [Y/T] : "; cin >> ya;
	cout <<endl;
	cin.ignore(1, '\n'); 

    jumlah = 0;	
	}
	while (ya == "Y"    || ya =="y");
	cout <<endl;
	closejudul ();
	
	return 0;
}
